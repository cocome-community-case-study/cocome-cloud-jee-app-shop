define(["require", "exports", "../../main", "../pages/search/SearchPageState"], function (require, exports, main_1, SearchPageState_1) {
    "use strict";
    var SearchComponent = (function () {
        function SearchComponent(value) {
            this.model = new SearchComponentModel(value);
        }
        SearchComponent.prototype.applyBinding = function (node) {
            var _this = this;
            this.removeBinding(node);
            setTimeout(function () {
                console.log(node.get(0));
                console.log(_this.model);
                ko.applyBindings(_this.model, node.get(0));
            }, 10);
        };
        SearchComponent.prototype.removeBinding = function (node) {
            setTimeout(function () {
                ko.cleanNode(node.get(0));
            }, 5);
        };
        return SearchComponent;
    }());
    exports.SearchComponent = SearchComponent;
    var SearchComponentModel = (function () {
        function SearchComponentModel(value) {
            this.search = {
                input: ko.observable(value),
                onEnter: function (data, event) {
                    if (event.keyCode == 13) {
                        var pageState = new SearchPageState_1.SearchPageState(this.input());
                        main_1.main.app.openPage(pageState);
                    }
                    return true;
                }
            };
        }
        return SearchComponentModel;
    }());
});
//# sourceMappingURL=SearchComponent.js.map