/**
 * Created by Joshua on 19.01.2017.
 */
export abstract class PageState {
    public abstract getPageName(): string
}
