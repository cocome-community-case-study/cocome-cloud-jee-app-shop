import {Page} from "../../../framework/Page";
import {PageState} from "../../../framework/PageState";
import {IndexPageState} from "./IndexPageState";
import {ToolbarComponent} from "../../uicomponents/ToolbarComponent";
import {SearchComponent} from "../../uicomponents/SearchComponent";
import {UiComponent} from "../../../framework/UiComponent";
import {CocomeAppSettings} from "../../CocomeAppSettings";
import {PageUiComponent} from "../../../framework/PageUiComponent";
/**
 * Created by Joshua on 19.01.2017.
 */
/// <reference path="../../../framework/Page.ts" />


export class IndexPage extends Page {

    private toolbar: UiComponent;
    private search: UiComponent;
    private uicomponent: UiComponent;

    public updatePage(pageState: PageState): void {
        console.log("Update Index", this.getDomNode());

        this.toolbar = new ToolbarComponent("Cocome App");
        this.toolbar.applyBinding(this.getContentDomNode().find("#toolbar"));

        this.search = new SearchComponent(CocomeAppSettings.APP_NAME);
        this.search.applyBinding(this.getContentDomNode().find("#search"));

        this.uicomponent = new IndexPageComponent();
        this.uicomponent.applyBinding(this.getContentDomNode());
    }

    public getDefaultPageState(): PageState {
        return new IndexPageState();
    }

    public closePage(): void {
        this.toolbar.removeBinding(this.getContentDomNode().find("#toolbar"));
        this.search.removeBinding(this.getContentDomNode());
    }
}

class IndexPageComponent extends PageUiComponent
{
    private model: IndexPageComponentModel;
    constructor()
    {
        super();
        this.model = new IndexPageComponentModel();
    }

    getModel(): any {
        return this.model;
    }
}

class IndexPageComponentModel{

    constructor() {
    }
}