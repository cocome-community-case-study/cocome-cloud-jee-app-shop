define(["require", "exports"], function (require, exports) {
    "use strict";
    var Service = (function () {
        function Service() {
            var _this = this;
            setTimeout(function () {
                _this.initService();
            });
        }
        return Service;
    }());
    exports.Service = Service;
});
//# sourceMappingURL=Service.js.map