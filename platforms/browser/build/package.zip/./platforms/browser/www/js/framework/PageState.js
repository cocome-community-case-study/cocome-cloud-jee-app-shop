define(["require", "exports"], function (require, exports) {
    "use strict";
    var PageState = (function () {
        function PageState() {
        }
        return PageState;
    }());
    exports.PageState = PageState;
});
//# sourceMappingURL=PageState.js.map