define(["require", "exports"], function (require, exports) {
    "use strict";
    var Templates = (function () {
        function Templates() {
        }
        Templates.load = function () {
            ToolbarVue.load();
        };
        return Templates;
    }());
    exports.Templates = Templates;
});
//# sourceMappingURL=templates.js.map