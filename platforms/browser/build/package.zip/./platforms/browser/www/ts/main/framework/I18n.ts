/**
 * Created by Joshua on 09.02.2017.
 */

export class I18n
{
    public static getI18n():any
    {
        return {
            interestingItems:"Items that you might like:",
            selectMarket:"Please select your store:",
            selectEnterprise: "Select Enterprise",
            selectStore: "Select Store",
            youSelected: "You selected",
            selection: "Selection",
            okay: "Okay",
            noShopSelected: "Please select a Store!",
            products: "Products",
            added: "Added",
            itemAdded: "Item added to Cart!"
        };
    };
}