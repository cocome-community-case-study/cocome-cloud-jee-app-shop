/**
 * Created by Joshua on 09.02.2017.
 */

export class I18n
{
    public static getI18n():any
    {
        return {};
    };
}