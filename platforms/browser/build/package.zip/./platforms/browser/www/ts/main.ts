/**
 * Created by Joshua on 15.01.2017.
 */

/// <reference path="libs/jquery/jquery.d.ts" />
/// <reference path="libs/onsenui/onsenui.d.ts" />

var app:App;

$(function() {
    app = new CococmeApp();
});