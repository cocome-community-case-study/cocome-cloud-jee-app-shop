/**
 * Created by Joshua on 09.02.2017.
 */

export class CocomeAppSettings {
    public static APP_NAME='Cocome App Shop';
}