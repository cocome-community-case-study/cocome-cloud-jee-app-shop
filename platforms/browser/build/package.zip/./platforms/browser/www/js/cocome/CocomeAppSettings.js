define(["require", "exports"], function (require, exports) {
    "use strict";
    var CocomeAppSettings = (function () {
        function CocomeAppSettings() {
        }
        CocomeAppSettings.APP_NAME = 'Cocome App Shop';
        CocomeAppSettings.APP_NAME_SHORT = "Cocome";
        return CocomeAppSettings;
    }());
    exports.CocomeAppSettings = CocomeAppSettings;
});
//# sourceMappingURL=CocomeAppSettings.js.map