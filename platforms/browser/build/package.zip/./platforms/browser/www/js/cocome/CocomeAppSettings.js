define(["require", "exports"], function (require, exports) {
    "use strict";
    var CocomeAppSettings = (function () {
        function CocomeAppSettings() {
        }
        return CocomeAppSettings;
    }());
    CocomeAppSettings.APP_NAME = 'Cocome App Shop';
    exports.CocomeAppSettings = CocomeAppSettings;
});
//# sourceMappingURL=CocomeAppSettings.js.map