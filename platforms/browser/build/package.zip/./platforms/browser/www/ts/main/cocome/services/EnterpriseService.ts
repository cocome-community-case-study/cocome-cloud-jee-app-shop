import {Service} from "../../framework/Service";
import {Item} from "../types/Item";
import {Enterprise} from "../types/Enterprice";
import {Store} from "../types/Store";
/**
 * Created by Joshua on 10.02.2017.
 */

export class EnterpriseService extends Service {
    private enterprises: Array<Enterprise> = [];

    constructor() {
        super();
    }

    initService(): void {
        let e1 = new Enterprise("Enterprise 123");

        e1.addStore(new Store("Store 1"));
        e1.addStore(new Store("Store 2"));
        e1.addStore(new Store("Store 3"));

        let e2 = new Enterprise("Enterprise 456");

        e2.addStore(new Store("Store 4"));
        e2.addStore(new Store("Store 5"));
        e2.addStore(new Store("Store 6"));

        let e3 = new Enterprise("Enterprise 789");

        e3.addStore(new Store("Store 7"));
        e3.addStore(new Store("Store 8"));
        e3.addStore(new Store("Store 9"));


        this.enterprises.push(e1);
        this.enterprises.push(e2);
        this.enterprises.push(e3);
    }

    closeService(): void {
    }

    public getEnterprises = (): Array<Enterprise> => {
        let result:Array<Enterprise> = new Array();

        $.ajax({
            url: "http://localhost:1234/api/enterprise/",
            async: false,
            dataType: "json"
        }).done(function (data:Array<Enterprise>) {
            for(let enterprise of data)
            {
                result.push(new Enterprise("").updateData(enterprise))
            }
        });

        return result;
    }


}