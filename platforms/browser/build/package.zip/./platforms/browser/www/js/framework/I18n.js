define(["require", "exports"], function (require, exports) {
    "use strict";
    var I18n = (function () {
        function I18n() {
        }
        I18n.getI18n = function () {
            return {};
        };
        ;
        return I18n;
    }());
    exports.I18n = I18n;
});
//# sourceMappingURL=I18n.js.map