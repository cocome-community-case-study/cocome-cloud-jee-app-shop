define(["require", "exports"], function (require, exports) {
    "use strict";
});
//# sourceMappingURL=Component.js.map