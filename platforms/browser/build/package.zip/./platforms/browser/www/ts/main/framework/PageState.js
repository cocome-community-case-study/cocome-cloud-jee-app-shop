/**
 * Created by Joshua on 19.01.2017.
 */
var PageState = (function () {
    function PageState() {
    }
    return PageState;
}());
