requirejs.config({
    baseUrl: 'libs/requirejs',
    paths: {
        app: '../../js',
        knockout: "../../libs/knockout/knockout-3.4.1.debug"
    }
});
requirejs(['main']);
//# sourceMappingURL=app.js.map