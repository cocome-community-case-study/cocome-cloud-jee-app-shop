requirejs.config({
    baseUrl: 'libs/requirejs',
    paths: {
        app: '../../js',
        knockout: "../../libs/knockout/knockout-min-3.4.1"
    }
});
requirejs(['main']);
//# sourceMappingURL=app.js.map