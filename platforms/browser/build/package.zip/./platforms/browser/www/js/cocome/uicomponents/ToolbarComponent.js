define(["require", "exports", "../../main"], function (require, exports, main_1) {
    "use strict";
    var ToolbarComponent = (function () {
        function ToolbarComponent() {
            var _this = this;
            this.setTitle = function (title) {
                _this.model.setTitle(title);
            };
            this.model = new ToolbarComponentModel("NaN NaN");
        }
        ToolbarComponent.prototype.applyBinding = function (node) {
            var _this = this;
            this.removeBinding(node);
            setTimeout(function () {
                console.log(node.get(0));
                console.log(_this.model);
                ko.applyBindings(_this.model, node.get(0));
            }, 10);
        };
        ToolbarComponent.prototype.removeBinding = function (node) {
            setTimeout(function () {
                ko.cleanNode(node.get(0));
            }, 5);
        };
        return ToolbarComponent;
    }());
    exports.ToolbarComponent = ToolbarComponent;
    var ToolbarComponentModel = (function () {
        function ToolbarComponentModel(title) {
            this.toolbar = {
                title: title,
                openMenu: function () {
                    main_1.main.app.openMenu();
                }
            };
        }
        ToolbarComponentModel.prototype.setTitle = function (title) {
            this.toolbar.title = title;
        };
        return ToolbarComponentModel;
    }());
});
//# sourceMappingURL=ToolbarComponent.js.map