/**
 * Created by Joshua on 09.02.2017.
 */
"use strict";
var CocomeAppSettings = (function () {
    function CocomeAppSettings() {
    }
    CocomeAppSettings.APP_NAME = 'Cocome App Shop';
    CocomeAppSettings.APP_NAME_SHORT = "Cocome";
    return CocomeAppSettings;
}());
exports.CocomeAppSettings = CocomeAppSettings;
